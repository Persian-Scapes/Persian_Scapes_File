const DATA = window.SITE_DATA;
const PLACEHOLDER = 'assets/images/placeholder.svg';

function $(selector) { return document.querySelector(selector); }
function $all(selector) { return Array.from(document.querySelectorAll(selector)); }
function byId(items, id) { return items.find(item => item.id === id); }
function getParam(name) { return new URLSearchParams(window.location.search).get(name); }
function safe(value, fallback = 'Not added yet') { return value === undefined || value === null || value === '' ? fallback : value; }
function asArray(value) { return Array.isArray(value) ? value : (value ? [value] : []); }
function imagePath(src) {
  if (!src || !src.trim()) return PLACEHOLDER;
  const clean = src.trim();
  if (clean.startsWith('images/')) return `assets/${clean}`;
  return clean;
}
function filmPageUrl(film) {
  return film && film.page ? film.page : `film-details.html?id=${encodeURIComponent(film.id)}`;
}
function themeMotifs(film) {
  const motifs = asArray(film?.theme?.motifs).slice(0, 3);
  return motifs.map(item => `<span class="theme-chip">${escapeHtml(item)}</span>`).join('');
}
function imgTag(src, alt, extraClass = '') {
  return `<img class="${extraClass}" src="${imagePath(src)}" alt="${escapeHtml(alt || 'Image placeholder')}" onerror="this.onerror=null;this.src='${PLACEHOLDER}';">`;
}
function escapeHtml(str) {
  return String(str ?? '').replace(/[&<>'"]/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[ch]));
}
function filmForLocation(location) { return byId(DATA.films, location.related_film); }
function locationsForFilm(film) { return DATA.locations.filter(loc => loc.related_film === film.id); }
function areaOf(location) { return location.neighborhood_or_area || location.current_address_or_area || 'Tehran'; }
function listHtml(items) {
  const arr = asArray(items).filter(Boolean);
  if (!arr.length) return '<p class="meta mb-0">You can add this later.</p>';
  return `<ul class="clean-list">${arr.map(item => `<li>${escapeHtml(item)}</li>`).join('')}</ul>`;
}
function setActiveNav() {
  const page = document.body.dataset.page;
  $all('[data-nav]').forEach(link => {
    if (link.dataset.nav === page) link.classList.add('active');
  });
}
function cardLocation(location) {
  const film = filmForLocation(location);
  return `
    <article class="museum-card">
      <div class="card-img-wrap">${imgTag(location.current_location_image || location.film_still_image, location.location_name_en)}</div>
      <div class="card-body-custom">
        <div class="d-flex gap-2 flex-wrap mb-3">
          <span class="badge rounded-pill badge-soft">${escapeHtml(location.match_level)}</span>
          <span class="badge rounded-pill badge-gold">${escapeHtml(location.city || 'Tehran')}</span>
        </div>
        <h3 class="h5 mb-1">${escapeHtml(location.location_name_en)}</h3>
        <p class="fa-text mb-2">${escapeHtml(location.location_name_fa)}</p>
        <p class="meta mb-2"><strong>Film:</strong> ${escapeHtml(film ? `${film.title_en} (${film.year})` : location.related_film)}</p>
        <p class="meta mb-2"><strong>Area:</strong> ${escapeHtml(areaOf(location))}</p>
        <p class="meta mb-3"><strong>Type:</strong> ${escapeHtml(location.place_type)}</p>
        <a class="btn btn-sm btn-cinema" href="location-details.html?id=${encodeURIComponent(location.id)}">Location Details</a>
      </div>
    </article>`;
}
function cardFilm(film) {
  const locs = locationsForFilm(film);
  const theme = film.theme || {};
  return `
    <article class="film-card themed-film-card" style="--card-accent:${escapeHtml(theme.accent || '#c9975d')}; --card-secondary:${escapeHtml(theme.secondary || '#2a1a17')};">
      <div class="card-img-wrap">${imgTag(film.poster_image || (locs[0] && locs[0].film_still_image), film.title_en)}</div>
      <div class="card-body-custom">
        <div class="theme-mini">${escapeHtml(theme.name || 'Film theme')}</div>
        <h3 class="h5 mb-1">${escapeHtml(film.title_en)}</h3>
        <p class="fa-text mb-2">${escapeHtml(film.title_fa)}</p>
        <p class="meta mb-1"><strong>Director:</strong> ${escapeHtml(film.director)}</p>
        <p class="meta mb-1"><strong>Year:</strong> ${escapeHtml(film.year)}</p>
        <p class="meta mb-2"><strong>Locations:</strong> ${locs.length}</p>
        <div class="theme-chip-row mb-3">${themeMotifs(film)}</div>
        <a class="btn btn-sm btn-cinema" href="${filmPageUrl(film)}">Film Details</a>
      </div>
    </article>`;
}
document.addEventListener('DOMContentLoaded', setActiveNav);
