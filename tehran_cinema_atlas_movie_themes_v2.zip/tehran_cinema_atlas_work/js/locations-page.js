function renderLocations() {
  const search = ($('#locationSearch').value || '').toLowerCase();
  const type = $('#typeFilter').value;
  const match = $('#matchFilter').value;
  const film = $('#filmFilter').value;

  const results = DATA.locations.filter(loc => {
    const f = filmForLocation(loc);
    const haystack = [loc.location_name_fa, loc.location_name_en, loc.place_type, loc.neighborhood_or_area, loc.match_level, f?.title_fa, f?.title_en].join(' ').toLowerCase();
    return (!search || haystack.includes(search)) &&
      (type === 'all' || loc.place_type === type) &&
      (match === 'all' || loc.match_level === match) &&
      (film === 'all' || loc.related_film === film);
  });

  $('#locationCount').textContent = `${results.length} / ${DATA.locations.length} locations`;
  $('#locationsGrid').innerHTML = results.length
    ? results.map(loc => `<div class="col-md-6 col-xl-4">${cardLocation(loc)}</div>`).join('')
    : '<div class="col-12"><div class="empty-state">No locations match your filters.</div></div>';
}

document.addEventListener('DOMContentLoaded', () => {
  const types = [...new Set(DATA.locations.map(l => l.place_type).filter(Boolean))].sort();
  $('#typeFilter').innerHTML += types.map(t => `<option value="${escapeHtml(t)}">${escapeHtml(t)}</option>`).join('');
  const matches = [...new Set(DATA.locations.map(l => l.match_level).filter(Boolean))].sort();
  $('#matchFilter').innerHTML += matches.map(m => `<option value="${escapeHtml(m)}">${escapeHtml(m)}</option>`).join('');
  $('#filmFilter').innerHTML += DATA.films.map(f => `<option value="${escapeHtml(f.id)}">${escapeHtml(f.title_en)} / ${escapeHtml(f.title_fa)}</option>`).join('');
  ['locationSearch','typeFilter','matchFilter','filmFilter'].forEach(id => document.getElementById(id).addEventListener('input', renderLocations));
  renderLocations();
});
