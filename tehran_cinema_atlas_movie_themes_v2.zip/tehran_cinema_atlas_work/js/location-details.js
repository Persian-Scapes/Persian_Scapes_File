document.addEventListener('DOMContentLoaded', () => {
  const id = getParam('id') || DATA.locations[0]?.id;
  const loc = byId(DATA.locations, id);
  if (!loc) {
    $('main').innerHTML = '<section class="container section"><div class="empty-state">Location not found.</div></section>';
    return;
  }
  const film = filmForLocation(loc);
  document.title = `${loc.location_name_en} | Location Details`;
  $('#breadcrumbTitle').textContent = loc.location_name_en;
  $('#titleEn').textContent = loc.location_name_en;
  $('#titleFa').textContent = loc.location_name_fa;
  $('#locationHero').innerHTML = imgTag(loc.current_location_image || loc.film_still_image, loc.location_name_en);
  $('#filmName').textContent = film ? `${film.title_en} / ${film.title_fa}` : loc.related_film;
  $('#address').textContent = loc.current_address_or_area || areaOf(loc);
  $('#area').textContent = areaOf(loc);
  $('#type').textContent = loc.place_type || 'Not added yet';
  $('#matchLevel').textContent = loc.match_level;
  $('#reason').textContent = loc.identification_reason;
  $('#scene').textContent = loc.scene_description || 'Add a short description of the film scene here.';
  $('#reality').textContent = loc.location_reality || 'Real location, not a studio set';
  $('#access').textContent = loc.visitor_access || 'Add visiting/access notes later.';
  $('#mapLink').href = loc.map_link || '#';
  if (!loc.map_link) $('#mapLink').classList.add('disabled');

  $('#thenImage').innerHTML = imgTag(loc.film_still_image, `${loc.location_name_en} film still`);
  $('#nowImage').innerHTML = imgTag(loc.current_location_image, `${loc.location_name_en} current photo`);
  $('#facts').innerHTML = listHtml(loc.facts_trivia);
  $('#evidence').innerHTML = listHtml(loc.evidence);
  $('#sources').innerHTML = listHtml(loc.sources.length ? loc.sources : ['Add bibliography, links, or image sources here.']);

  const relatedFilmLink = film ? `<a href="${filmPageUrl(film)}">Open Film Details</a>` : '';
  $('#relatedFilmLink').innerHTML = relatedFilmLink;
});
