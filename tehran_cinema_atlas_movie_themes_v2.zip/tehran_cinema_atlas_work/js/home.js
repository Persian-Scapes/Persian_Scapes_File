document.addEventListener('DOMContentLoaded', () => {
  $('#statLocations').textContent = DATA.project.location_count;
  $('#statFilms').textContent = DATA.project.film_count;
  $('#statCity').textContent = DATA.project.city;

  const featuredWanted = ['golestan', 'moshir', 'music museum'];
  const featured = [];
  for (const key of featuredWanted) {
    const found = DATA.locations.find(loc => `${loc.location_name_en} ${loc.location_name_fa}`.toLowerCase().includes(key));
    if (found && !featured.some(x => x.id === found.id)) featured.push(found);
  }
  while (featured.length < 3 && DATA.locations[featured.length]) featured.push(DATA.locations[featured.length]);

  $('#featuredLocations').innerHTML = featured.map(loc => `<div class="col-md-4">${cardLocation(loc)}</div>`).join('');
});
