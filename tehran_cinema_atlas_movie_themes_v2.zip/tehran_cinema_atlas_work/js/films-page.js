function renderFilms() {
  const search = ($('#filmSearch').value || '').toLowerCase();
  const results = DATA.films.filter(f => {
    const haystack = [f.title_fa, f.title_en, f.director, f.year, f.short_description].join(' ').toLowerCase();
    return !search || haystack.includes(search);
  });
  $('#filmCount').textContent = `${results.length} films`;
  $('#filmsGrid').innerHTML = results.length
    ? results.map(f => `<div class="col-md-6 col-xl-4">${cardFilm(f)}</div>`).join('')
    : '<div class="col-12"><div class="empty-state">No films match your search.</div></div>';
}
document.addEventListener('DOMContentLoaded', () => {
  $('#filmSearch').addEventListener('input', renderFilms);
  renderFilms();
});
