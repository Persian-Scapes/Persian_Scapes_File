document.addEventListener('DOMContentLoaded', () => {
  const id = document.body.dataset.filmId || getParam('id') || DATA.films[0]?.id;
  const film = byId(DATA.films, id);
  if (!film) {
    $('main').innerHTML = '<section class="container section"><div class="empty-state">Film not found.</div></section>';
    return;
  }

  const theme = film.theme || {};
  const locs = locationsForFilm(film);
  applyFilmTheme(theme, film);

  document.title = `${film.title_en} | Film Details`;
  $('#filmTitleEn').textContent = film.title_en;
  $('#filmTitleFa').textContent = film.title_fa;
  $('#director').textContent = film.director || 'Not added yet';
  $('#year').textContent = film.year || 'Not added yet';
  $('#filmDescription').textContent = film.short_description || 'Add a short film description here.';
  $('#poster').innerHTML = imgTag(film.poster_image || locs[0]?.film_still_image, film.title_en);
  $('#locationTotal').textContent = locs.length;
  $('#filmFacts').innerHTML = listHtml(film.facts_trivia);
  $('#filmSources').innerHTML = listHtml(film.sources.length ? film.sources : ['Add film sources, poster sources, or bibliography here.']);

  setText('#filmThemeName', theme.name || 'Film Theme');
  setText('#filmThemeNameFa', theme.name_fa || 'تم فیلم');
  setText('#filmMood', theme.mood || 'Add a short explanation of this film’s visual mood and how the page design represents it.');
  $('#themeMotifs').innerHTML = asArray(theme.motifs).map(item => `<span class="theme-chip big">${escapeHtml(item)}</span>`).join('');
  $('#palette').innerHTML = asArray(theme.palette).map(color => `<span class="palette-dot" style="background:${escapeHtml(color)}" title="${escapeHtml(color)}"></span>`).join('');
  $('#themeExplain').innerHTML = `
    <p class="mb-2"><strong>How this page is themed:</strong></p>
    <p class="meta mb-0">The page uses CSS variables for the film colors, background gradient, badges, borders, and buttons. JavaScript reads the film ID, finds the matching theme data, and applies it to this page.</p>
  `;

  setupDialogueAudio(theme, film);

  const galleryImages = [];
  if (film.poster_image) galleryImages.push({src: film.poster_image, alt: film.title_en});
  locs.forEach(loc => {
    if (loc.film_still_image) galleryImages.push({src: loc.film_still_image, alt: `${loc.location_name_en} film still`});
    if (loc.current_location_image) galleryImages.push({src: loc.current_location_image, alt: `${loc.location_name_en} current photo`});
  });
  $('#gallery').innerHTML = galleryImages.slice(0, 9).map(item => imgTag(item.src, item.alt)).join('') || '<p class="meta">Add film stills and archive photos here.</p>';
  $('#filmLocations').innerHTML = locs.length
    ? locs.map(loc => `<div class="col-md-6">${cardLocation(loc)}</div>`).join('')
    : '<div class="col-12"><div class="empty-state">No related locations connected yet.</div></div>';
});

function setText(selector, text) {
  const el = $(selector);
  if (el) el.textContent = text;
}

function applyFilmTheme(theme, film) {
  document.body.classList.add('film-themed-page');
  document.body.dataset.themeName = theme.name || film.title_en;
  const style = document.documentElement.style;
  style.setProperty('--film-primary', theme.primary || '#070b12');
  style.setProperty('--film-secondary', theme.secondary || '#201018');
  style.setProperty('--film-accent', theme.accent || '#c9975d');
  style.setProperty('--film-soft', theme.soft || '#e9d0a4');
  style.setProperty('--film-ink', theme.ink || '#fff3df');
  style.setProperty('--film-pattern', theme.pattern || 'linear-gradient(135deg, #1a1010, #3b1717)');
}

function setupDialogueAudio(theme, film) {
  const audio = $('#dialogueAudio');
  const button = $('#dialogueButton');
  const status = $('#audioStatus');
  if (!audio || !button) return;

  audio.src = theme.dialogue_audio || '';
  status.textContent = theme.dialogue_audio
    ? `Audio path prepared: ${theme.dialogue_audio}. Replace this file with your real dialogue clip.`
    : 'Add an audio path inside js/data.js to activate this feature.';

  button.addEventListener('click', () => {
    if (!theme.dialogue_audio) {
      status.textContent = 'No audio file added yet. Put a short dialogue clip in assets/audio/ and add its path in js/data.js.';
      return;
    }
    if (audio.paused) {
      audio.play().then(() => {
        button.textContent = 'Pause dialogue';
        status.textContent = `Playing a dialogue sample from ${film.title_en}.`;
      }).catch(() => {
        status.textContent = 'The audio file path exists in the code, but the actual mp3 file has not been added yet.';
      });
    } else {
      audio.pause();
      button.textContent = 'Play dialogue';
      status.textContent = 'Dialogue paused.';
    }
  });

  audio.addEventListener('ended', () => {
    button.textContent = 'Play dialogue';
    status.textContent = 'Dialogue finished.';
  });
}
